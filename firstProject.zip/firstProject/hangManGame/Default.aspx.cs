﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hangManGame
{
    public partial class WebForm1 : System.Web.UI.Page
    {



        protected void Page_Load(object sender, EventArgs e)
        {
            //string[] randomWords = { "greenr", "blueer", "yellow", "redred", "orange", "indigo", "violet" };
            //Random rnd = new Random();
            //int randNum = rnd.Next(0, 7);
            //string answer = randomWords[randNum];
            //int wordLength = answer.Length;
            //char[] answerChars = answer.ToCharArray();
            //string[] guessDisplay = new string[wordLength];
            //char[] answerCheck = new char[wordLength];
            //int lives = 0;
            //bool guessCheck = false;
            //bool dupeCheck = false;
            //char userGuess = ' ';
            //string answerMatch = "";
        }

        //public static string[] randomWords = { "greenr", "blueer", "yellow", "redred", "orange", "indigo", "violet" };
        //public static Random rnd = new Random();
        //public static int randNum = rnd.Next(0, 7);
        //public static string answer = randomWords[randNum];
        //public static int wordLength = answer.Length;
        //public static char[] answerChars = answer.ToCharArray();
        //public static string[] guessDisplay = new string[wordLength];
        //public static char[] answerCheck = new char[wordLength];
        //public static int lives = 0;
        //public static bool guessCheck = false;
        //public static bool dupeCheck = false;
        //public char userGuess = ' ';
        //public string answerMatch = "";

        //protected void Page_Unload(object sender, EventArgs e)
        //{
        //    resetQuiz();

        //}

        static string[] randomWords = { "greenr", "blueer", "yellow", "redred", "orange", "indigo", "violet" };
        static Random rnd = new Random();
        static int randNum = rnd.Next(0, 7);
        static string answer = randomWords[randNum];
        static int wordLength = answer.Length;
        static char[] answerChars = answer.ToCharArray();
        static string[] guessDisplay = new string[wordLength];
        static char[] answerCheck = new char[wordLength];
        static int lives = 0;
        static bool guessCheck = false;
        static bool dupeCheck = false;
        char userGuess = ' ';
        string answerMatch = "";
        
        public void resetQuiz(){
           
            Random rnd = new Random();
            randNum = rnd.Next(0, 7);
            answer = randomWords[randNum];
            wordLength = answer.Length;
            answerChars = answer.ToCharArray();
            guessDisplay = new string[wordLength];
            answerCheck = new char[wordLength];
            answerMatch = "";
            userGuess = ' ';
        }

        static string CheckAnswer(char[] answerCheck)
        {
            string answerMatch = new string(answerCheck);
            return answerMatch;
        }

        static bool CheckDupe(string guesses, string guess)
        {
            bool output = guesses.Contains(guess);
            return output;
        }

        private string updateGuessDisplay(string[] guessDisplayArray, int inputIndex, char[] answerArray)
        {
            string guessDisplayOutput = "";

            for (int i = 0; i < wordLength; i += 1)
            {


                if (i == inputIndex)
                {
                    guessDisplayArray[i] = answerArray[i].ToString() + "     ";
                }

                else if (inputIndex == 99)
                {
                    guessDisplayArray[i] = "_     ";
                }
                guessDisplayOutput += guessDisplayArray[i];

            }

            return guessDisplayOutput;
        }

        protected void startButton_Click(object sender, EventArgs e)
        {

            Panel1.Visible = true;
            Panel2.Visible = true;
            testingResponse.Text = answer;
            wordLengthVisualiser.Text = updateGuessDisplay(guessDisplay, 99, answerChars);

        }

        protected void guessButton_Click(object sender, EventArgs e)
        {
            userGuess = Convert.ToChar(guess.Text);


            for (int i = 0; i < wordLength; i += 1)
            {
                if (userGuess == answerChars[i])
                {
                    guessCheck = true;

                    if (userGuess == answerCheck[i])
                    {
                        dupeCheck = true;
                    }

                    else
                    {

                        answerCheck[i] = answerChars[i];
                        wordLengthVisualiser.Text = updateGuessDisplay(guessDisplay, i, answerChars);


                    }
                }
            }
            if (guessCheck == true)
            {
                answerMatch = CheckAnswer(answerCheck);

                if (answerMatch == answer)
                {
                    guessResponse.Text = "You got it! The word was " + answer;
                    //feedback.ForeColor = Color.Green;
                    //feedback.Text = "\u00fc";
                    guessCheck = false;
                    //guessButton.Enabled = false;
                    //startButton.Visible = false;
                    //closeButton.Visible = true;
                    resetQuiz();
                }
                else if (dupeCheck == true)
                {
                    guessResponse.Text = "You already guessed that one";
                    dupeCheck = false;
                    guessCheck = false;
                }

                else
                {
                    guessResponse.Text = "Well Done! Keep Guessing";
                    //feedback.ForeColor = Color.Green;
                    //feedback.Text = "\u00fc";
                    guessCheck = false;
                }
            }

            else
            {

                dupeCheck = CheckDupe(guessedLetters.Text, guess.Text);
                if (dupeCheck)
                {
                    guessResponse.Text = "You already guessed that one";

                }

                else
                {
                    lives += 1;

                    guessedLetters.Text += guess.Text + " ";

                    if (lives == 1)
                    {
                        gallows.Visible = false;
                        lifeOne.Visible = true;
                        guessResponse.Text = "Incorrect, guess again";
                        //feedback.ForeColor = Color.Red;
                        //feedback.Text = "\u00fb";
                    }
                    else if (lives == 2)
                    {
                        lifeOne.Visible = false;
                        lifeTwo.Visible = true;
                        guessResponse.Text = "Incorrect, guess again";
                        //feedback.ForeColor = Color.Red;
                        //feedback.Text = "\u00fb";
                    }
                    else if (lives == 3)
                    {
                        lifeTwo.Visible = false;
                        lifeThree.Visible = true;
                        guessResponse.Text = "Incorrect, guess again";
                        //feedback.ForeColor = Color.Red;
                        //feedback.Text = "\u00fb";
                    }
                    else if (lives == 4)
                    {
                        lifeThree.Visible = false;
                        lifeFour.Visible = true;
                        guessResponse.Text = "Incorrect, guess again";
                        //feedback.ForeColor = Color.Red;
                        //feedback.Text = "\u00fb";
                    }

                    else if (lives == 5)
                    {
                        lifeFour.Visible = false;
                        lifeFive.Visible = true;
                        guessButton.Enabled = false;
                        guessResponse.Text = "You lost, the word was " + answer;
                        //feedback.ForeColor = Color.PaleVioletRed;
                        //feedback.Text = "\u00fb";
                        //startButton.Visible = false;
                        //closeButton.Visible = true;
                        resetQuiz();
                    }
                    else
                    {
                        guessResponse.Text = "ERROR";
                    }
                }
            }
            guess.Text = "";
        }

        protected void Quit_Click(object sender, EventArgs e)
        {
            resetQuiz();
        }
    }
}